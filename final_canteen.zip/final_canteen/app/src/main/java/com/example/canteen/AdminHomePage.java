package com.example.canteen;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AdminHomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_home_page);
        final Button btnCanteen=findViewById(R.id.btnAddCanteen);
        final Button viewCanteen=findViewById(R.id.btnViewCanteen);
        final Button addStudentButton=findViewById(R.id.btnAddStudent);
        final Button viewStudent=findViewById(R.id.btnViewStudent);
        final Button editCanteen=findViewById(R.id.btnEditCanteen);
        final Button editStudent=findViewById(R.id.btnEditStudent);
        final Button addBalanceForStudent=findViewById(R.id.btnAddBalance);
        final Button withdrawBalanceForStudent=findViewById(R.id.btnWithDrawBalance);
        final Button deleteStudent=findViewById(R.id.btnDeleteStudent);
        final Button deleteCanteen=findViewById(R.id.btnDeleteCanteen);
        final Button homePage=findViewById(R.id.homePageAdmin);




        btnCanteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(AdminHomePage.this,AddCanteen.class);
                startActivity(objIntent);
            }
        });
        viewCanteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(AdminHomePage.this,ViewCanteen.class);
                startActivity(obj);
            }
        });
        addStudentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(AdminHomePage.this,AddStudent.class);
                startActivity(obj);
            }
        });
        viewStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(AdminHomePage.this,ViewStudent.class);
                startActivity(obj);
            }
        });
        editCanteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(AdminHomePage.this,EditCanteen.class);
                startActivity(obj);
            }
        });
        editStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(AdminHomePage.this,EditStudent.class);
                startActivity(obj);
            }
        });
        addBalanceForStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(AdminHomePage.this,AdminAddBalance.class);
                startActivity(obj);
            }
        });
        withdrawBalanceForStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(AdminHomePage.this,AdminWithdrawBalance.class);
                startActivity(obj);
            }
        });
        deleteStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(AdminHomePage.this,DeleteStudent.class);
                startActivity(obj);
            }
        });
        deleteCanteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(AdminHomePage.this,DeleteCanteen.class);
                startActivity(obj);
            }
        });
        homePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(AdminHomePage.this,MainActivity.class);
                startActivity(obj);

            }
        });












    }
}
