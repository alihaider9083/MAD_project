package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.RunnableScheduledFuture;

import androidx.appcompat.app.AppCompatActivity;

public class AddStudent extends AppCompatActivity {
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_student);
        final EditText name=findViewById(R.id.studentName);
        final EditText rollNumber=findViewById(R.id.rollNumber);
        final EditText email=findViewById(R.id.email);
        final EditText studentMobileNumber=findViewById(R.id.studentMobileNumber);
        final EditText section=findViewById(R.id.section);
        final EditText balance=findViewById(R.id.balance);
        final Button addStudent=findViewById(R.id.btnAddStudent);


        addStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    if(name.getText().toString().equals("") || rollNumber.getText().toString().equals("") || email.getText().toString().equals("")||studentMobileNumber.getText().toString().equals("") || section.getText().toString().equals("") || balance.getText().toString().equals(""))
                    {
                        Toast.makeText(getApplicationContext(),"Please fill all the fields ",Toast.LENGTH_SHORT).show();
                        // Intent intent=new Intent(AddCanteen.this,AddCanteen.class);
                        //startActivity(intent);

                    }
                    else{

                        Student  student=new Student(name.getText().toString(),rollNumber.getText().toString(),email.getText().toString(),studentMobileNumber.getText().toString(),section.getText().toString(),Integer.parseInt(balance.getText().toString()));
                        reference= FirebaseDatabase.getInstance().getReference().child("Student");
                        reference.push().setValue(student);
                        Toast.makeText(getApplicationContext(),"Data inserted Successfully",Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(AddStudent.this,AdminHomePage.class);
                        startActivity(intent);



                    }

                }}


        });


    }
}
