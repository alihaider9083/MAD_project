package com.example.canteen;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.RunnableScheduledFuture;

import androidx.appcompat.app.AppCompatActivity;
public class AddItem extends AppCompatActivity{
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);
        final EditText itemID=findViewById(R.id.itemID);
        final EditText itemName=findViewById(R.id.itemName);
        final EditText itemDescription=findViewById(R.id.itemDescription);
        final EditText itemCost=findViewById(R.id.itemCost);
        final EditText itemTime=findViewById(R.id.itemTime);
        final Button addItem=findViewById(R.id.btnAddItem);
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    if(itemID.getText().toString().equals("") || itemName.getText().toString().equals("") || itemDescription.getText().toString().equals("")||itemCost.getText().toString().equals("") || itemTime.getText().toString().equals("") )
                    {
                        Toast.makeText(getApplicationContext(),"Please fill all the fields ",Toast.LENGTH_SHORT).show();


                    }
                    else{

                     Item item=new Item(itemID.getText().toString(),itemName.getText().toString(),itemDescription.getText().toString(),Integer.parseInt(itemCost.getText().toString()),itemTime.getText().toString());
                        reference= FirebaseDatabase.getInstance().getReference().child("Item");
                        reference.push().setValue(item);
                        Toast.makeText(getApplicationContext(),"Data inserted Successfully",Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(AddItem.this,CanteenHomePage.class);
                        startActivity(intent);



                    }

                }}


        });
    }
}
