package com.example.canteen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentHomePage extends AppCompatActivity {
private DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_home_page);
       final Button viewItem=findViewById(R.id.btnViewMenu);
        final Button addBalance=findViewById(R.id.btnAddBalance);
        final Button PlaceOrder=findViewById(R.id.btnReviewPlaceOrder);
        final Button homePage=findViewById(R.id.homePageStudent);
        final Button transaction=findViewById(R.id.btnViewTransactions);

        viewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(StudentHomePage.this,ShowMenuToStudent.class);
                startActivity(obj);
            }
        });
        addBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(StudentHomePage.this,StudentAddBalance.class);
                startActivity(obj);

            }
        });


        homePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(StudentHomePage.this,MainActivity.class);
                startActivity(obj);

            }
        });
        PlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
                final String rollNumber=sp.getString("rollNumber","rollNumber");
                reference= FirebaseDatabase.getInstance().getReference().child("Student");
                ValueEventListener eventListener = new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                    {
                        Intent i = null;
                        for (DataSnapshot ds : dataSnapshot.getChildren())

                        {
                            String rollNumberFromFirebase = ds.child("rollNumber").getValue(String.class);
                            if (rollNumberFromFirebase.equals(rollNumber))
                            {
                                //Toast.makeText(getApplicationContext(),ds.getKey(),Toast.LENGTH_SHORT).show();
                                i = new Intent(StudentHomePage.this, PlaceOrder.class);
                                i.putExtra("rollNumber", rollNumberFromFirebase);
                                i.putExtra("studentPath", ds.getKey());
                                startActivity(i);

                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }

                };
                reference.addListenerForSingleValueEvent(eventListener);

            }
        });
        transaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(StudentHomePage.this,ViewTransaction.class);
                startActivity(obj);

            }
        });


    }
}

