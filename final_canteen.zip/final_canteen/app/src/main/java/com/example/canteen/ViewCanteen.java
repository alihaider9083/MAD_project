package com.example.canteen;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class ViewCanteen extends AppCompatActivity {

    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_canteen);

        /*
        final EditText managementNameEditText=findViewById(R.id.managementName);
        final EditText handlerEditText=findViewById(R.id.holder);
        final EditText mobileEditText=findViewById(R.id.mobileNo);
        final EditText numberOfWorkersEditText=findViewById(R.id.numberOfWorkers);
        final EditText addressEditText=findViewById(R.id.address);
*/

        reference=FirebaseDatabase.getInstance().getReference().child("Canteen");
        final TextView textViews=(TextView)findViewById(R.id.textViewResult);

        ValueEventListener eventListener = new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String managementName = ds.child("managementName").getValue(String.class);
                    String holder = ds.child("holder").getValue(String.class);
                    String mobile = ds.child("mobile").getValue(String.class);
                    String numberOfWorker = ds.child("numberOfWorkers").getValue().toString();
                    String address = ds.child("address").getValue(String.class);
                    //Canteen  c=new Canteen(managementName,holder,mobile,Integer.parseInt(numberOfWorker),address);

                    /*managementNameEditText.setText(managementName);
                    handlerEditText.setText(holder);
                    mobileEditText.setText(mobile);
                    numberOfWorkersEditText.setText(numberOfWorker);
                    addressEditText.setText(address);*/


                textViews.append("\n\n\nManagement Name : "+managementName);
                textViews.append("\nHolder : "+holder);
                textViews.append("\nMobile : "+mobile);
                textViews.append("\nNumber Of Workers : "+numberOfWorker);
                textViews.append("\nAddress : "+address);




                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        reference.addListenerForSingleValueEvent(eventListener);




    }



}
