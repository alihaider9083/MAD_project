package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class EditCanteen extends AppCompatActivity
{
    private DatabaseReference reference;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_canteen);
        final EditText canteenMobileNumber=findViewById(R.id.canteenMobileNumberForUpdateCheck);
        final Button editCanteen=findViewById(R.id.editCanteen);

        editCanteen.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                    if (canteenMobileNumber.getText().toString().equals(""))
                    {
                        Toast.makeText(getApplicationContext(), "Please enter mobile Number ", Toast.LENGTH_SHORT).show();
                        // Intent intent=new Intent(AddCanteen.this,AddCanteen.class);
                        //startActivity(intent);

                    } else {
                        reference=FirebaseDatabase.getInstance().getReference().child("Canteen");
                        ValueEventListener eventListener = new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Intent i=null;
                                for (DataSnapshot ds : dataSnapshot.getChildren())
                                {
                                    String mobileNumberFromFirebase = ds.child("mobile").getValue(String.class);
                                    if (mobileNumberFromFirebase.equals(canteenMobileNumber.getText().toString())) {
                                        //Toast.makeText(getApplicationContext(),ds.getKey(),Toast.LENGTH_SHORT).show();
                                         i = new Intent(EditCanteen.this, UpdateCanteen.class);
                                        i.putExtra("mobileNumber",mobileNumberFromFirebase);
                                        i.putExtra("path",ds.getKey());
                                        startActivity(i);

                                    }
                                }
                                if(i==null)
                                    Toast.makeText(getApplicationContext(),"Not register any canteen with this mobile number",Toast.LENGTH_SHORT).show();

                            }


                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        };
                        reference.addListenerForSingleValueEvent(eventListener);
                    }
                }
            });
        }
    }
