package com.example.canteen;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class ViewStudent extends AppCompatActivity {

    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_student);



        reference= FirebaseDatabase.getInstance().getReference().child("Student");
        final TextView textViews=(TextView)findViewById(R.id.textViewStudent);


        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String name = ds.child("name").getValue(String.class);
                    String rollNumber = ds.child("rollNumber").getValue(String.class);
                    String email = ds.child("email").getValue(String.class);
                    String mobileNo = ds.child("mobileNo").getValue().toString();
                    String section = ds.child("section").getValue(String.class);
                    String balance=ds.child("balance").getValue().toString();
                    
                    textViews.append("\n\n\nStudent Name : "+name);
                    textViews.append("\nRoll Number : "+rollNumber);
                    textViews.append("\nEmail : "+email);
                    textViews.append("\nMobile Number : "+mobileNo);
                    textViews.append("\nSection : "+section);
                    textViews.append("\nBalancce : "+balance);






                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        reference.addListenerForSingleValueEvent(eventListener);




    }



}
