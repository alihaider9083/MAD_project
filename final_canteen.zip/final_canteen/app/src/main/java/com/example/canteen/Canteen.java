package com.example.canteen;

import android.widget.EditText;

import com.google.firebase.database.PropertyName;

public class Canteen {
    @PropertyName("managementName")
    private String managementName;
    @PropertyName("holder")
    private String holder;
    @PropertyName("mobile")
    private String mobile;
    @PropertyName("numberOfWorkers")
    private int numberOfWorkers;
    @PropertyName("address")
    private String address;

    public Canteen(String managementName, String holder, String mobile, int numberOfWorkers, String address) {
        this.managementName = managementName;
        this.holder = holder;
        this.mobile = mobile;
        this.numberOfWorkers = numberOfWorkers;
        this.address = address;
    }


    public String getManagementName() {
        return managementName;
    }

    public void setManagementName(String managementName) {
        this.managementName = managementName;
    }

    public String getHolder() {
        return holder;
    }

    public void setHolder(String holder) {
        this.holder = holder;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public int getNumberOfWorkers() {
        return numberOfWorkers;
    }

    public void setNumberOfWorkers(int numberOfWorkers) {
        this.numberOfWorkers = numberOfWorkers;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
