package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateCanteen extends AppCompatActivity {
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_canteen);
        final EditText managementName = findViewById(R.id.managementNameUpdate);
        final EditText handler = findViewById(R.id.holderUpdate);
        final EditText mobile = findViewById(R.id.mobileNoUpdate);
        final EditText numberOfWorkers = findViewById(R.id.numberOfWorkersUpdate);
        final EditText address = findViewById(R.id.addressUpdate);
        final Button addCanteen = findViewById(R.id.btnUpdateCanteen);


        addCanteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    if (managementName.getText().toString().equals("") || handler.getText().toString().equals("") || mobile.getText().toString().equals("") || numberOfWorkers.getText().toString().equals("") || address.getText().toString().equals("")) {
                        Toast.makeText(getApplicationContext(), "Please fill all the fields ", Toast.LENGTH_SHORT).show();
                        // Intent intent=new Intent(AddCanteen.this,AddCanteen.class);
                        //startActivity(intent);

                    } else {
                        Intent intent=getIntent();
                        Bundle bundle=intent.getExtras();

                        String mobileNumberFromIntent= bundle.getString("mobileNumber");
                        String path=bundle.getString("path");
                        //Toast.makeText(getApplicationContext(),path,Toast.LENGTH_SHORT).show();


                        Canteen c = new Canteen(managementName.getText().toString(), handler.getText().toString(), mobile.getText().toString(), Integer.parseInt(numberOfWorkers.getText().toString()), address.getText().toString());
                        reference = FirebaseDatabase.getInstance().getReference("Canteen").child(path);
                       Map<String,Object> map=new HashMap<>();
                        map.put("managementName",managementName.getText().toString());
                        map.put("holder",handler.getText().toString());
                        map.put("mobile",mobile.getText().toString());
                        map.put("numberOfWorkers",numberOfWorkers.getText().toString());
                        map.put("address",address.getText().toString());
                        reference.updateChildren(map);

                        Toast.makeText(getApplicationContext(), "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                        Intent intents = new Intent(UpdateCanteen.this, AdminHomePage.class);
                        startActivity(intents);


                    }

                }
            }


        });

    }
}
