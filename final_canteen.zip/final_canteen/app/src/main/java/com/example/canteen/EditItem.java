package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class EditItem extends AppCompatActivity
{
    private DatabaseReference reference;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_item);
        final EditText itemID=findViewById(R.id.itemIDForUpdateCheck);
        final Button edititem=findViewById(R.id.btnEditItem);

        edititem.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (itemID.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter id ", Toast.LENGTH_SHORT).show();


                } else {
                    reference=FirebaseDatabase.getInstance().getReference().child("Item");
                    ValueEventListener eventListener = new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Intent i=null;
                            for (DataSnapshot ds : dataSnapshot.getChildren())
                            {
                                String idNumberFromFirebase = ds.child("id").getValue(String.class);
                                if (idNumberFromFirebase.equals(itemID.getText().toString())) {
                                    //Toast.makeText(getApplicationContext(),ds.getKey(),Toast.LENGTH_SHORT).show();
                                    i = new Intent(EditItem.this, UpdateItem.class);
                                    i.putExtra("id",idNumberFromFirebase);
                                    i.putExtra("itemPath",ds.getKey());
                                    startActivity(i);

                                }
                            }
                            if(i==null)
                                Toast.makeText(getApplicationContext(),"Not register any item with this id",Toast.LENGTH_SHORT).show();

                        }


                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    };
                    reference.addListenerForSingleValueEvent(eventListener);
                }
            }
        });
    }
}
