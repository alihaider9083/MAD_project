package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;

public class AddCanteen extends AppCompatActivity {
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_canteen);
        final EditText managementName=findViewById(R.id.managementName);
        final EditText handler=findViewById(R.id.holder);
        final EditText mobile=findViewById(R.id.mobileNo);
        final EditText numberOfWorkers=findViewById(R.id.numberOfWorkers);
        final EditText address=findViewById(R.id.address);
        final Button addCanteen=findViewById(R.id.btnAddCanteen);


        addCanteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    if(managementName.getText().toString().equals("") || handler.getText().toString().equals("") || mobile.getText().toString().equals("")|| numberOfWorkers.getText().toString().equals("") ||address.getText().toString().equals(""))
                    {
                        Toast.makeText(getApplicationContext(),"Please fill all the fields ",Toast.LENGTH_SHORT).show();
                       // Intent intent=new Intent(AddCanteen.this,AddCanteen.class);
                        //startActivity(intent);

                    }
                    else{

                        Canteen  c=new Canteen(managementName.getText().toString(),handler.getText().toString(),mobile.getText().toString(),Integer.parseInt(numberOfWorkers.getText().toString()),address.getText().toString());
                        reference= FirebaseDatabase.getInstance().getReference().child("Canteen");
                        reference.push().setValue(c);
                        Toast.makeText(getApplicationContext(),"Data inserted Successfully",Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(AddCanteen.this,AdminHomePage.class);
                        startActivity(intent);



                    }

                }
            }
                


        });


    }
}
