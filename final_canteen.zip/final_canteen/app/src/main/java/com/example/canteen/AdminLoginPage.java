package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_loginpage);
        final EditText objID=findViewById(R.id.edxAdminID);
        final EditText objPassword=findViewById(R.id.txtAdminPassword);
        Button objButton=findViewById(R.id.btnAdminLogin);


        objButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    if(objID.getText().toString().equals("Admin") &&  objPassword.getText().toString().equals("Admin") || objID.getText().toString().equals("admin") &&  objPassword.getText().toString().equals("admin")) {
                        Intent objIntent = new Intent(getApplicationContext(), AdminHomePage.class);
                        startActivity(objIntent);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Wrong Credentials",Toast.LENGTH_SHORT).show();
                        Intent objIntent2 = new Intent(getApplicationContext(), AdminLoginPage.class);
                        startActivity(objIntent2);
                    }
                }

            }
        });






    }
}
