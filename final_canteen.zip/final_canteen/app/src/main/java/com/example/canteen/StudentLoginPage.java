package com.example.canteen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentLoginPage extends AppCompatActivity {
    private DatabaseReference reference;
    public SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_loginpage);
        reference = FirebaseDatabase.getInstance().getReference().child("Student");

        final EditText objID = findViewById(R.id.edxStudentID);
        final EditText objPassword = findViewById(R.id.txtStudentPassword);
        final Button objButton = findViewById(R.id.btnStudentLogin);
        sp = getSharedPreferences("login",MODE_PRIVATE);

        objButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValueEventListener valueEventListener=new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                    {
                        Intent objIntent = null;
                        for (DataSnapshot ds : dataSnapshot.getChildren())
                        {
                            final String name = ds.child("name").getValue(String.class);
                            final String rollNumber = ds.child("rollNumber").getValue(String.class);

                            if (objID.getText().toString().equals(name) && objPassword.getText().toString().equals(rollNumber)) {
                                objIntent = new Intent(getApplicationContext(), StudentHomePage.class);
                                sp.edit().putString("rollNumber",rollNumber).apply();
                                startActivity(objIntent);
                                break;
                            }
                        }
                        if (objIntent == null)
                        {
                            Toast.makeText(getApplicationContext(), "Incorrect user  id and password", Toast.LENGTH_SHORT).show();

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }


                };
                reference.addListenerForSingleValueEvent(valueEventListener);


            }

        });
    }

}