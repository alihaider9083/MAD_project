package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class StudentAddBalance extends AppCompatActivity
{
    private DatabaseReference reference;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_add_balance);
        final EditText studentRollNumber=findViewById(R.id.studentRollNumberForAddBalanceFromStudent);
        final EditText studentNewBalance=findViewById(R.id.newBalanceStudent);


        final Button editStudent=findViewById(R.id.addStudentBalanceStudent);

        editStudent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (studentRollNumber.getText().toString().equals("") || studentNewBalance.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please fill both the  fields ", Toast.LENGTH_SHORT).show();

                } else
                {
                    reference = FirebaseDatabase.getInstance().getReference().child("Student");
                    ValueEventListener eventListener = new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Intent i=null;
                            for (DataSnapshot ds : dataSnapshot.getChildren())
                            {
                                String rollNumberFromFirebase = ds.child("rollNumber").getValue(String.class);
                                String balanceFromFirebase =  ds.child("balance").getValue().toString();
                                if (rollNumberFromFirebase.equals(studentRollNumber.getText().toString()))
                                {
                                    //Toast.makeText(getApplicationContext(),ds.getKey(),Toast.LENGTH_SHORT).show();
                                    DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Student").child(ds.getKey());
                                    int balance = Integer.parseInt(balanceFromFirebase) + Integer.parseInt(studentNewBalance.getText().toString());
                                    Map<String, Object> map = new HashMap<>();
                                    map.put("balance", balance);
                                    reference1.updateChildren(map);

                                    Toast.makeText(getApplicationContext(), "Balance Updated Successfully", Toast.LENGTH_SHORT).show();
                                    i=new Intent(StudentAddBalance.this,StudentHomePage.class);
                                    i.putExtra("rollNumber",rollNumberFromFirebase);
                                    startActivity(i);
                                    //  break;
                                }
                            }
                            if (i==null){
                                Toast.makeText(getApplicationContext(), "Not register any student with this Roll Number", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError)
                        {

                        }
                    };
                    reference.addListenerForSingleValueEvent(eventListener);
                }
            }
        });

    }
}
