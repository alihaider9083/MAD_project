package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class DeleteStudent extends AppCompatActivity
{
    private DatabaseReference reference;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete_student);
        final EditText studentRollNumber=findViewById(R.id.studentRollNumberForDeleteCheck);
        final Button deleteStudent=findViewById(R.id.deleteStudent);

        deleteStudent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (studentRollNumber.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter roll Number ", Toast.LENGTH_SHORT).show();
                    // Intent intent=new Intent(AddCanteen.this,AddCanteen.class);
                    //startActivity(intent);

                } else {
                    reference=FirebaseDatabase.getInstance().getReference().child("Student");
                    ValueEventListener eventListener = new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Intent i=null;
                            for (DataSnapshot ds : dataSnapshot.getChildren())
                            {
                                String rollNumberFromFirebase = ds.child("rollNumber").getValue(String.class);
                                if (rollNumberFromFirebase.equals(studentRollNumber.getText().toString())) {
                                    i = new Intent(DeleteStudent.this, AdminHomePage.class);
                                    DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Student").child(ds.getKey());
                                    reference1.removeValue();
                                    Toast.makeText(getApplicationContext(),"Student deleted Successfully",Toast.LENGTH_SHORT).show();


                                    startActivity(i);
                                    break;

                                }
                            }
                            if(i==null)
                                Toast.makeText(getApplicationContext(),"Not register any student with this Roll Number",Toast.LENGTH_SHORT).show();

                        }


                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    };
                    reference.addListenerForSingleValueEvent(eventListener);
                }
            }
        });
    }
}
