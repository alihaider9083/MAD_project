package com.example.canteen;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class CanteenHomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.canteen_home_page);
        Button addItem=findViewById(R.id.btnAddItems);
        Button viewItem=findViewById(R.id.btnViewItems);
        Button editItem=findViewById(R.id.btnEditItems);
        Button deleteItem=findViewById(R.id.btnDeleteItems);
        Button addBalance=findViewById(R.id.btnAddBalanceCanteen);
        Button withDrawBalance=findViewById(R.id.btnWithDrawBalance);
        Button ViewOrder=findViewById(R.id.btnViewNewOrders);
        final Button homePage=findViewById(R.id.homePageCanteen);
       addItem.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent obj=new Intent(CanteenHomePage.this,AddItem.class);
               startActivity(obj);
           }
       });
        viewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,ViewItem.class);
                startActivity(obj);
            }
        });
        editItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,EditItem.class);
                startActivity(obj);
            }
        });
        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,DeleteItem.class);
                startActivity(obj);
            }
        });
        addBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,CanteenAddBalance.class);
                startActivity(obj);
            }
        });
        withDrawBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,StudentWithDrawBalance.class);
                startActivity(obj);
            }
        });
        homePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,MainActivity.class);
                startActivity(obj);

            }
        });
        ViewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(CanteenHomePage.this,ViewOrder.class);
                startActivity(obj);
            }
        });




    }
}