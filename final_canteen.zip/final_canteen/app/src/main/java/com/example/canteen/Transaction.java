package com.example.canteen;

public class Transaction {
    private String rollNumber;
    private String itemName;
    private int quantity;
    private String date;
    private int totalCost;

    public Transaction(String rollNumber, String itemName, int quantity, String date, int totalCost) {
        this.rollNumber = rollNumber;
        this.itemName = itemName;
        this.quantity = quantity;
        this.date = date;
        this.totalCost = totalCost;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(int totalCost) {
        this.totalCost = totalCost;
    }
}
