package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CanteenLoginPage extends AppCompatActivity {
    private DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.canteen_loginpage);
        reference = FirebaseDatabase.getInstance().getReference().child("Canteen");
        final EditText objID = findViewById(R.id.edxCanteenID);
        final EditText objPassword = findViewById(R.id.txtCanteenPassword);
        final Button objButton = findViewById(R.id.btnCanteenLogin);

        objButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValueEventListener valueEventListener=new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                    {
                        Intent objIntent = null;
                        for (DataSnapshot ds : dataSnapshot.getChildren())
                        {
                            final String name = ds.child("managementName").getValue(String.class);
                            final String mobileNo = ds.child("mobile").getValue(String.class);

                            if (objID.getText().toString().equals(name) && objPassword.getText().toString().equals(mobileNo)) {
                                objIntent = new Intent(getApplicationContext(), CanteenHomePage.class);
                                startActivity(objIntent);
                                break;
                            }
                        }
                        if (objIntent == null)
                        {
                            Toast.makeText(getApplicationContext(), "Incorrect user  id and password", Toast.LENGTH_SHORT).show();

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }


                };
                reference.addListenerForSingleValueEvent(valueEventListener);


            }

        });
    }

}