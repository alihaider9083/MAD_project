package com.example.canteen;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static java.lang.Integer.parseInt;

public class PlaceOrder extends AppCompatActivity {
    private DatabaseReference referenceStudent;
    private DatabaseReference referenceItem;
    private  String ItemName;
    private  String itemCost;
    private String balanceStudent;
    private boolean itemFound=false;
    private int updateBalance;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.place_order);

        final EditText item1=findViewById(R.id.itemName1);
        final EditText quantity1=findViewById(R.id.itemQuantity1);
        Button btnReturn=findViewById(R.id.btnReturn);
        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();




        referenceStudent = FirebaseDatabase.getInstance().getReference().child("Student");
        referenceItem=FirebaseDatabase.getInstance().getReference().child("Item");

        final Button placeOrder=findViewById(R.id.btnPlaceOrder);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        final String rollNumberFromSharedPreferences=sp.getString("rollNumber","rollNumber");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    String rollNumber = ds.child("rollNumber").getValue().toString();
                    if(rollNumber.equals(rollNumberFromSharedPreferences)){
                        balanceStudent=ds.child("balance").getValue().toString();
                        // break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        referenceStudent.addListenerForSingleValueEvent(eventListener);




        placeOrder.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(item1.getText().toString().equals("") || quantity1.getText().toString().equals(""))
                {
                    Toast.makeText(getApplicationContext(),"Please fill both the fields",Toast.LENGTH_SHORT).show();
                }
                else {



                    ValueEventListener eventListenerItem = new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot ds : dataSnapshot.getChildren())
                            {
                                String itemName = ds.child("name").getValue().toString();
                                int totalCost;

                                if(itemName.equals(item1.getText().toString()))
                                {
                                    itemFound=true;
                                    itemCost=ds.child("cost").getValue().toString();
                                    String quantity=quantity1.getText().toString();
                                    totalCost=Integer.parseInt(quantity)*Integer.parseInt(itemCost);
                                    if(totalCost>Integer.parseInt(balanceStudent)){
                                        Toast.makeText(getApplicationContext(),"Your balance is low for this order",Toast.LENGTH_SHORT).show();

                                    }
                                    else{
                                        //    int totalCostForTransaction=updateBalance;

                                        updateBalance=Integer.parseInt(balanceStudent)-totalCost;
                                        Intent intent=getIntent();
                                        Bundle bundle=intent.getExtras();

                                        String rollNumberFromIntent= bundle.getString("rollNumber");
                                        String path=bundle.getString("studentPath");

                                        referenceStudent = FirebaseDatabase.getInstance().getReference("Student").child(path);
                                        //reference = FirebaseDatabase.getInstance().getReference("Student").child(path);
                                        Map<String,Object> map=new HashMap<>();
                                        map.put("balance",updateBalance);
                                        referenceStudent.updateChildren(map);
                                        String date = java.text.DateFormat.getDateTimeInstance().format(new Date());

                                        Transaction t=new Transaction(rollNumberFromIntent,itemName,Integer.parseInt(quantity1.getText().toString()),date,totalCost);
                                        DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Transaction");
                                        reference.push().setValue(t);

                                        Toast.makeText(getApplicationContext(),"Order place successfully",Toast.LENGTH_SHORT).show();
                                    }
                                }

                            }
                            if(itemFound==false)
                            {
                                Toast.makeText(getApplicationContext(),"Item Not found",Toast.LENGTH_SHORT).show();
                            }
                        }


                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    };
                    referenceItem.addListenerForSingleValueEvent(eventListenerItem);





                }
            }
        });
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i = new Intent(PlaceOrder.this, StudentHomePage.class);
                startActivity(i);
            }
        });

    }
}