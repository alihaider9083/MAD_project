package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateStudent extends AppCompatActivity {
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_student);
        final EditText studentName = findViewById(R.id.studentNameUpdate);
        final EditText rollNumber = findViewById(R.id.studentRollNumberUpdate);
        final EditText email = findViewById(R.id.emailUpdate);
        final EditText mobileNumber = findViewById(R.id.mobileNumberStudentUpdate);
        final EditText section = findViewById(R.id.sectionUpdate);
        final EditText balance=findViewById(R.id.balanceUpdate);
        final Button buttonStudent = findViewById(R.id.btnUpdateStudent);

        buttonStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (studentName.getText().toString().equals("") || rollNumber.getText().toString().equals("") || email.getText().toString().equals("") || mobileNumber.getText().toString().equals("") || section.getText().toString().equals("") || balance.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Please fill all the fields ", Toast.LENGTH_SHORT).show();
                        // Intent intent=new Intent(AddCanteen.this,AddCanteen.class);
                        //startActivity(intent);
                    }
                else
                    {
                        Intent intent=getIntent();
                        Bundle bundle=intent.getExtras();

                        String rollNumberFromIntent= bundle.getString("rollNumber");
                        String path=bundle.getString("studentPath");
                       Student s=new Student(studentName.getText().toString(),rollNumber.getText().toString(),email.getText().toString(),mobileNumber.getText().toString(),section.getText().toString(),Integer.parseInt(balance.getText().toString()));


                        reference = FirebaseDatabase.getInstance().getReference("Student").child(path);
                        Map<String,Object> map=new HashMap<>();
                        map.put("name",studentName.getText().toString());
                        map.put("rollNumber",rollNumber.getText().toString());
                        map.put("email",email.getText().toString());
                        map.put("mobileNo",mobileNumber.getText().toString());
                        map.put("section",section.getText().toString());
                        map.put("balance",balance.getText().toString());
                        reference.updateChildren(map);

                        Toast.makeText(getApplicationContext(), "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                        Intent intents = new Intent(UpdateStudent.this, AdminHomePage.class);
                        startActivity(intents);


                    }

                }



        });

    }
}
