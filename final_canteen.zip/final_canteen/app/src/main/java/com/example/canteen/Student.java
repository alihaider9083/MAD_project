package com.example.canteen;

import java.util.jar.Attributes;

public class Student {
    private String name;
    private String rollNumber;
    private String email;
    private String mobileNo;
    private String section;
    private int balance;

    public Student(String name, String rollNumber, String email, String mobileNo,String section,int balance) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.email = email;
        this.mobileNo=mobileNo;
        this.section = section;
        this.balance=balance;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
