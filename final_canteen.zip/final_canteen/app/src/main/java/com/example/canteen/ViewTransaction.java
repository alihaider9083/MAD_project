package com.example.canteen;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class ViewTransaction extends AppCompatActivity {

    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_transaction);



        reference= FirebaseDatabase.getInstance().getReference().child("Transaction");
        final TextView textViews=(TextView)findViewById(R.id.textViewTransaction);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        final String rollNumberFromSharedPreferences=sp.getString("rollNumber","rollNumber");


        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    if(ds.child("rollNumber").getValue(String.class).equals(rollNumberFromSharedPreferences))
                    {
                        String name = ds.child("itemName").getValue(String.class);
                        String quantity = ds.child("quantity").getValue().toString();
                        String date = ds.child("date").getValue(String.class);
                        String totalCost = ds.child("totalCost").getValue().toString();

                        textViews.append("\n\n\nItem : " + name);
                        textViews.append("\nQuantity : " + quantity);
                        textViews.append("\nDate : " + date);
                        textViews.append("\nTotal Cost : " + totalCost);


                    }


                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        reference.addListenerForSingleValueEvent(eventListener);




    }
}
