package com.example.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateItem extends AppCompatActivity {
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_item);
        final EditText itemID=findViewById(R.id.updateItemID);
        final EditText itemName=findViewById(R.id.updateItemName);
        final EditText itemDescription=findViewById(R.id.updateItemDescription);
        final EditText itemCost=findViewById(R.id.updateItemCost);
        final EditText itemTime=findViewById(R.id.updateItemTime);
        final Button addItem=findViewById(R.id.btnUpdateItem);

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (itemID.getText().toString().equals("") || itemName.getText().toString().equals("") || itemDescription.getText().toString().equals("") || itemCost.getText().toString().equals("") || itemTime.getText().toString().equals("") ){
                    Toast.makeText(getApplicationContext(), "Please fill all the fields ", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Intent intent=getIntent();
                    Bundle bundle=intent.getExtras();

                    String idFromIntent= bundle.getString("id");
                    String path=bundle.getString("itemPath");
                    Item i=new Item(itemID.getText().toString(),itemName.getText().toString(),itemDescription.getText().toString(),Integer.parseInt(itemCost.getText().toString()),itemTime.getText().toString());


                    reference = FirebaseDatabase.getInstance().getReference("Item").child(path);
                    Map<String,Object> map=new HashMap<>();
                    map.put("id",itemID.getText().toString());
                    map.put("name",itemName.getText().toString());
                    map.put("description",itemDescription.getText().toString());
                    map.put("cost",itemCost.getText().toString());
                    map.put("time",itemTime.getText().toString());

                    reference.updateChildren(map);

                    Toast.makeText(getApplicationContext(), "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                    Intent intents = new Intent(UpdateItem.this, CanteenHomePage.class);
                    startActivity(intents);


                }

            }



        });

    }
}
