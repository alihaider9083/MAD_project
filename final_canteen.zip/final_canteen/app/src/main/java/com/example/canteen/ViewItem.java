package com.example.canteen;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class ViewItem extends AppCompatActivity {

    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_item);



        reference= FirebaseDatabase.getInstance().getReference().child("Item");
        final TextView textViews=(TextView)findViewById(R.id.textViewItem);


        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String ItemID = ds.child("id").getValue(String.class);
                    String ItemName = ds.child("name").getValue(String.class);
                    String ItemDescription = ds.child("description").getValue(String.class);
                    String itemCost = ds.child("cost").getValue().toString();
                    String itemTime = ds.child("time").getValue(String.class);

                    textViews.append("\n\n\nItem ID : "+ItemID);
                    textViews.append("\nitem Name : "+ItemName);
                    textViews.append("\nItem Description : "+ItemDescription);
                    textViews.append("\nitem Cost : "+itemCost);
                    textViews.append("\nItem Time : "+itemTime);







                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        reference.addListenerForSingleValueEvent(eventListener);




    }



}